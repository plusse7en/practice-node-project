'use strict';

/**
* practice Node.js project by Dataguru
* @author Plusseven Wang <jackwangjiaqi@qq.com>
*/

/*
$.method('user.add').call({
  name: 'hello2',
  email: 'xxxxx@qq.com',
  password: '123456',
  nickname: '测试1',
  about: '好厉害啊',
}, console.log);
*/

$.method('user.get').call({
  name: 'hello2',
}, console.log);

/*
$.method('user.update').call({
  name: 'hello2',
  nickname: '我是7',
}, console.log);
*/
