module.exports = function(set,get,has) {
  set('db.mongodb','mongodb://192.168.99.100:32769/prac_node');
};
